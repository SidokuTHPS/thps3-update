#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <vector>
#include <d3d9.h>