#ifndef DRAWER_H
#define DRAWER_H
#pragma unmanaged
void DrawScene();
#endif