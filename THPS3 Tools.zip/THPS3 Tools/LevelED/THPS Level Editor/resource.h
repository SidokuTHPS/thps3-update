//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by app.rc

#define IDR_DLL_BIN 102
#define IDR_DLL_BIN2 103
